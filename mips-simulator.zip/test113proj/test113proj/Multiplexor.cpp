#include "Multiplexor.h"



Multiplexor::Multiplexor(uint32_t input1, uint32_t input2, uint32_t sel)
{
	mux_out = input1 & ~sel | input2 & sel;
}


Multiplexor::~Multiplexor()
{
}
