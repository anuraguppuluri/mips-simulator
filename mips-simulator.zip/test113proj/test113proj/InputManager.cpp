#include "InputManager.h"


CInputManager::CInputManager()
{
  
}

CInputManager::CInputManager(string file_name, CInstructionMemory& InstMem, CDataMemory& DataMem)
{
	// Read content of input file 
	// populate text and memory segments
	ifstream inFile;
	// use escape sequence backslash
	inFile.open(file_name); 
	if (inFile.fail()) {
		// error message specific cout
		cerr << "Error Opening File" << endl;
		// exit_faiure as opposed to exit(0) exit_success
		exit(1);
	}

	string inAddr, inWord;
	uint32_t temp_hex = 0x0;
	map<uint32_t, uint32_t>::iterator it;

	// text_segment populated 
	it = InstMem.text_segment.begin();
	while (inFile >> inWord) {
		if (inWord == "DATA") {
			break;
		}
		stringstream ss;
		ss << hex << inWord;
		ss >> temp_hex;
		InstMem.text_segment[it->first] = temp_hex;
		it++;
	}

	// data_segment populated 
	it = DataMem.data_segment.begin();
	if (inFile >> inWord && inWord == "SEGMENT") {
		while (inFile >> inAddr >> inWord) {
			stringstream ss;
			ss << hex << inWord;
			ss >> temp_hex;
			DataMem.data_segment[it->first] = temp_hex;
			it++;
		}
	}
}


CInputManager::~CInputManager()
{
}


