#pragma once
#include<iostream>
#include<fstream>
#include<iterator>
#include<string>
#include<map>
#include<sstream>
using namespace std;

#include "ALU.h"
#include "ControlUnit.h"
#include "Multiplexor.h"
#include "InstructionMemory.h"
#include "Stack.h"

class CDataMemory
{
public:
	// define map for data space
	map<uint32_t, uint32_t> data_segment;
	uint32_t data_addr = 0x10010000;

	uint32_t data_out, write_data;
	
	CDataMemory();
	int PrintDataMem();
	int GetDataAtAddress(ALU&, CInstructionMemory&, CStack&); // sets data_out to data at this address
	int WriteRegData(ALU&, ControlUnit&);
	int WriteDataToMem(RegFile&, ControlUnit&, ALU&, CInstructionMemory&, CStack&);
	~CDataMemory();
};

