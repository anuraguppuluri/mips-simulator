#include<iostream>
#include<fstream>
#include<iterator>
#include<string>
#include<map>
#include<sstream>

#include "InstructionMemory.h"
#include "DataMemory.h"

#pragma once

using namespace std; 

class CInputManager
{
private: 
	string filename; 
public:
	CInputManager();
	CInputManager(string file_name, CInstructionMemory&, CDataMemory&);
	~CInputManager();

};

