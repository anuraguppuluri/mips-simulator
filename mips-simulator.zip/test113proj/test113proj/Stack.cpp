#include "Stack.h"



CStack::CStack()
{
	for (int i = 0; i < 512; i++) {
		stack_segment.insert(make_pair(stack_addr, 0x00000000));
		stack_addr -= 0x4;
	}
}

int CStack::PrintStack()
{
	// test memory segment
	int i = 1;
	map<uint32_t, uint32_t>::iterator it;
	cout << "*********************STACK***********************" << endl;
	for (it = stack_segment.begin(); it != stack_segment.end(); it++) {
		if (it->second == 0) break;
		cout << dec << i++ << " ";
		cout << hex << it->first << " -> " << it->second << endl;
	}

	cout << dec << "Size: " << stack_segment.size() << endl;
	return 0;
}

uint32_t CStack::GetStackValue(uint32_t addr)
{
	return stack_segment[addr];
}

CStack::~CStack()
{
}
