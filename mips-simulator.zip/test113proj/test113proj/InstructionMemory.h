#pragma once
#include<iostream>
#include<fstream>
#include<iterator>
#include<string>
#include<map>
#include<sstream>
using namespace std;

class CInstructionMemory
{
public: 
    // Instruction memory map
	// define map for instruction space
	map<uint32_t, uint32_t> text_segment;
	uint32_t text_addr = 0x00400000;

	uint32_t op, rs, rt, rd, shamt, funct, imm16, branchImm16, imm26;

	CInstructionMemory();
	uint32_t GetTextAtAddress(uint32_t); // Returns value at this address
	//SetTextAddressAt(uint32_t addr, uint32_t value);
	//uint32_t GetTextAtOffset(uint32_t addr, uint32_t offset); // 
	//uint32_t GetNextAddress(uint32_t addr, uint32_t offset);
	int PrintInstrMem();
	int GetInstrFields(uint32_t);
	~CInstructionMemory();
};

