#include "DataMemory.h"



CDataMemory::CDataMemory()
{
	for (int i = 0; i < 1024; i++) {
		data_segment.insert(make_pair(data_addr, 0x00000000));
		data_addr += 0x4;
	}
}

int CDataMemory::PrintDataMem()
{
	// test memory segment
	int i = 1;
	map<uint32_t, uint32_t>::iterator it;
	cout << "*********************DATA*MEMORY***********************" << endl;
	for (it = data_segment.begin(); it != data_segment.end(); it++) {
		if (it->second == 0) break;
		cout << dec << i++ << " ";
		cout << hex << it->first << " -> " << it->second << endl;
	}

	cout << dec << "Size: " << data_segment.size() << endl;
	return 0;
}

int CDataMemory::GetDataAtAddress(ALU& ALU1, CInstructionMemory& InstMem, CStack& St)
{
	int byte_num = ALU1.ALUResult % 4; // if accessing a byte or halfword

	// lb, lbu
	if (InstMem.op == 32 || InstMem.op == 36) {
		ALU1.ALUResult -= byte_num; // make sure it is word aligned at all times

		switch (byte_num) {
		case 0:
			data_out = (data_segment[ALU1.ALUResult] & 0xff000000) >> 24;
			break;
		case 1:
			data_out = (data_segment[ALU1.ALUResult] & 0x00ff0000) >> 16;
			break;
		case 2:
			data_out = (data_segment[ALU1.ALUResult] & 0x0000ff00) >> 8;
			break;
		case 3:
			data_out = (data_segment[ALU1.ALUResult] & 0x000000ff);
			break;
		default:
			cout << "Sorry! Not a byte-aligned address being accessed." << endl;
		}
		int sign_bit = data_out >> 7;
		if (sign_bit && InstMem.op == 32)
			data_out |= 0xffffff00;
	}

	// lh, lhu
	else if (InstMem.op == 33 || InstMem.op == 37) {
		ALU1.ALUResult -= byte_num; // make sure it is word aligned at all times

		switch (byte_num) {
		case 0:
			data_out = (data_segment[ALU1.ALUResult] & 0xffff0000) >> 16;
			break;
		case 2:
			data_out = (data_segment[ALU1.ALUResult] & 0x0000ffff);
			break;
		default:
			cout << "Sorry! Not a halfword-aligned address being accessed." << endl;
		}
		int sign_bit = data_out >> 15;
		if (sign_bit && InstMem.op == 33)
			data_out |= 0xffff0000;
	}

	else if (data_segment.find(ALU1.ALUResult) != data_segment.end()) {
		data_out = data_segment[ALU1.ALUResult];
	}

	else if (St.stack_segment.find(ALU1.ALUResult) != St.stack_segment.end()) {
		data_out = St.stack_segment[ALU1.ALUResult];
	}

	return 0;
}

// what should be written back to the register file ? ALUResult : data read from memory
int CDataMemory::WriteRegData(ALU& ALU1, ControlUnit& CU1) {
	Multiplexor dataALUMux = Multiplexor(ALU1.ALUResult, data_out, CU1.MemToReg);
	write_data = dataALUMux.mux_out;
	;	return 0;
}

// write data to memory if it's a store
int CDataMemory::WriteDataToMem(RegFile& RF1, ControlUnit& CU1, ALU& ALU1, CInstructionMemory& InstMem, CStack& St) {
	int byte_num = ALU1.ALUResult % 4; // if accessing a byte or halfword

	uint32_t mask_pattern;

	// sb
	if (InstMem.op == 40) {
		ALU1.ALUResult -= byte_num; // make sure it is word aligned at all times

		// complete mask pattern and store at appropriate byte position
		switch (byte_num) {
		case 0:
			mask_pattern = RF1.rt_data << 24;
			data_segment[ALU1.ALUResult] &= 0x00ffffff; // clear insert position
			data_segment[ALU1.ALUResult] |= mask_pattern; // insert
			break;
		case 1:
			mask_pattern = RF1.rt_data << 16;
			data_segment[ALU1.ALUResult] &= 0xff00ffff; // clear insert position
			data_segment[ALU1.ALUResult] |= mask_pattern; // insert
			break;
		case 2:
			mask_pattern = RF1.rt_data << 8;
			data_segment[ALU1.ALUResult] &= 0xffff00ff; // clear insert position
			data_segment[ALU1.ALUResult] |= mask_pattern; // insert
			break;
		case 3:
			mask_pattern = RF1.rt_data;
			data_segment[ALU1.ALUResult] &= 0xffffff00; // clear insert position
			data_segment[ALU1.ALUResult] |= mask_pattern; // insert
			break;
		default:
			cout << "Sorry! Not a byte-aligned address being accessed." << endl;
		}
	}

	// sh
	else if (InstMem.op == 41) {
		ALU1.ALUResult -= byte_num; // make sure it is word aligned at all times

		// complete mask pattern and store at appropriate halfword position
		switch (byte_num) {
		case 0:
			mask_pattern = RF1.rt_data << 16;
			data_segment[ALU1.ALUResult] &= 0x0000ffff; // clear insert position
			data_segment[ALU1.ALUResult] |= mask_pattern; // insert
			break;
		case 2:
			mask_pattern = RF1.rt_data;
			data_segment[ALU1.ALUResult] &= 0xffff0000; // clear insert position
			data_segment[ALU1.ALUResult] |= mask_pattern; // insert
			break;
		default:
			cout << "Sorry! Not a halfword-aligned address being accessed." << endl;
		}
	}

	else if (CU1.MemWrite && data_segment.find(ALU1.ALUResult) != data_segment.end()) {
		data_segment[ALU1.ALUResult] = RF1.rt_data;
	}

	else if (CU1.MemWrite && St.stack_segment.find(ALU1.ALUResult) != St.stack_segment.end()) {
		St.stack_segment[ALU1.ALUResult] = RF1.rt_data;
	}

	return 0;
}


CDataMemory::~CDataMemory()
{
}
