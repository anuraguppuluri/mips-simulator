#include "InstructionMemory.h"

CInstructionMemory::CInstructionMemory()
{
	for (int i = 0; i < 512; i++) {
		text_segment.insert(make_pair(text_addr, 0x00000000));
		text_addr += 0x4;
	}
}

int CInstructionMemory::PrintInstrMem()
{
	// test memory segment
	int i = 1;
	map<uint32_t, uint32_t>::iterator it;
	cout << "*********************INSTRUCTION*MEMORY***********************" << endl;
	for (it = text_segment.begin(); it != text_segment.end(); it++) {
		if (it->second == 0) break;
		cout << dec << i++ << " ";
		cout << hex << it->first << " -> " << it->second << endl;
	}

	cout << dec << "Size: "<< text_segment.size() << endl;
	return 0;
}

int CInstructionMemory::GetInstrFields(uint32_t instr) {
	
	// extract opcode field
	op = instr & 0xfc000000;
	op >>= 26;

	//cout << instr << endl;
	//cout << op << endl;

	// extract rs field
	rs = instr & 0x03e00000;
	rs >>= 21;

	//cout << rs << endl;

	// extract rt field
	rt = instr & 0x001f0000;
	rt >>= 16;

	//cout << rt << endl;

	// extract rd field
	rd = instr & 0x0000f800;
	rd >>= 11;

	//cout << rd << endl;

	// extract shamt field
	shamt = instr & 0x000007c0;
	shamt >>= 6;

	//cout << shamt << endl;

	// extract funct field
	funct = instr & 0x0000003f;

	//cout << funct << endl;

	// extract imm16 field and sign extend for ALU
	imm16 = instr & 0x0000ffff;
	int sign_bit = imm16 >> 15;
	if (sign_bit)
		imm16 |= 0xffff0000;
	if (op == 12 || op == 13 || op == 14) // andi, ori, xori
		imm16 &= 0x0000ffff;
	if (op == 15) // lui
		imm16 <<= 16;

	// shift imm16 by 2 for branch instruction
	branchImm16 = imm16 << 2;

	//cout << imm16 << endl;
	//cout << branchImm16 << endl;

	// extract imm26 field
	imm26 = instr & 0x03ffffff;
	imm26 <<= 2; // shift left by 2 for jump instruction

	//cout << imm26 << endl;

	return 0;
}

uint32_t CInstructionMemory::GetTextAtAddress(uint32_t addr)
{
	if (text_segment.find(addr) != text_segment.end())
		return text_segment[addr];
}

CInstructionMemory::~CInstructionMemory()
{
}
