#pragma once
#include<iostream>
#include<fstream>
#include<iterator>
#include<string>
#include<map>
#include<sstream>
using namespace std;

class ALUControl
{
public:
	uint32_t ALUCtrlOut;

	ALUControl();
	int SetALUCtrl(uint32_t, uint32_t, uint32_t);
	~ALUControl();
};

