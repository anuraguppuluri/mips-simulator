#include "ALUControl.h"



ALUControl::ALUControl()
{
	ALUCtrlOut = 0;
}


int ALUControl::SetALUCtrl(uint32_t ALUOp, uint32_t funct, uint32_t op) {
	// could be ADD, ADDI, ADDU, LW, SW, LUI, LB, LBU, LH, LHU, SB, SH
	// funct: ADD = 100000, ADDU = 100001
	if (ALUOp == 0 || (op == 0 && funct == 32) || (op == 0 && funct == 33))
		ALUCtrlOut = 2; // add

	// could be SUB, SUBU, SLT, SLTU, SLTI, SLTIU, branch;
	// funct: SUB = 100010, SUBU = 100011, SLT = 101010, SLTU = 101011
	else if (ALUOp == 1 || (op == 0 && funct == 34) || (op == 0 && funct == 35) || (op == 0 && funct == 42) || (op == 0 && funct == 43))
		ALUCtrlOut = 6; // subtract

	// could be r-format AND or i-format ANDI
	// funct: AND = 100100
	else if ((op == 0 && funct == 36) || op == 12)
		ALUCtrlOut = 0; // bitwise and

	// could be r-format OR or i-format ORI
	// funct: OR = 100101
	else if ((op == 0 && funct == 37) || op == 13)
		ALUCtrlOut = 1; // bitwise or

	// could be r-format XOR or i-format XORI
	// funct: XOR = 100110
	else if ((op == 0 && funct == 38) || op == 14)
		ALUCtrlOut = 3; // bitwise xor

	// funct: NOR = 100111
	else if (op == 0 && funct == 39)
		ALUCtrlOut = 12; // bitwise not or

	// funct: SLL = 000000, SLLV = 000100
	else if ((op == 0 && funct == 0) || (op == 0 && funct == 4))
		ALUCtrlOut = 4; // shift left logical

	// funct: SRL = 000010, SRLV = 000110, SRA = 000011, SRAV = 000111
	else if ((op == 0 && funct == 2) || (op == 0 && funct == 6) || (op == 0 && funct == 3) || (op == 0 && funct == 7))
		ALUCtrlOut = 5; // shift right logical or arithmetic

	// funct: MOVZ = 001010, MOVN = 001011, MFHI = 010000, MFLO = 010010, MTHI = 010001, MTLO = 010011
	else if ((op == 0 && funct == 10) || (op == 0 && funct == 11) || (op == 0 && funct == 16) || (op == 0 && funct == 18) || (op == 0 && funct == 17) || (op == 0 && funct == 19))
		ALUCtrlOut = 7; // move register content

	// funct: MULTU = 011001, MULT = 011000
	else if ((op == 0 && funct == 25) || (op == 0 && funct == 24))
		ALUCtrlOut = 8; // multiply

	// funct: DIVU = 011011, DIV = 011010
	else if ((op == 0 && funct == 27) || (op == 0 && funct == 26))
		ALUCtrlOut = 9; // divide

	// funct: JR = 001000, JALR = 001001
	else if ((op == 0 && funct == 8) || (op == 0 && funct == 9))
		ALUCtrlOut = 10; // jump

	// funct: SYSCALL: 001100
	else if (op == 0 && funct == 12)
		ALUCtrlOut = 11; // syscall

	return 0;
}

ALUControl::~ALUControl()
{
}
