#pragma once
#include<iostream>
#include<fstream>
#include<iterator>
#include<string>
#include<map>
#include<sstream>
using namespace std;

class Multiplexor
{
public:
	uint32_t mux_out;
	Multiplexor(uint32_t, uint32_t, uint32_t);
	~Multiplexor();
};

