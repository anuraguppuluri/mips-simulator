#include "ALU.h"



ALU::ALU()
{
	ALUResult = 0; Zero = 0;
}

int ALU::ResetALU() {
	ALUResult = 0; Zero = 0;
	return 0;
}

int ALU::ALUCalc(RegFile& RF1, ALUControl& ALUCt1, ControlUnit& CU1, CInstructionMemory& InstMem, ProgramCounter& PC1, map<uint32_t, uint32_t> data_segment) {
	ResetALU();
	RF1.ReadRS(InstMem);
	uint32_t input1 = RF1.rs_data;
	uint32_t input2 = RF1.ALUInput2(InstMem, CU1);

	uint32_t shift_amt = InstMem.shamt;
	// for sllv, srlv, srav shift amount is the low-order 5 bits of rs
	if (InstMem.funct == 4 || InstMem.funct == 6 || InstMem.funct == 7)
		shift_amt = input1 & 0x0000001f;

	switch (ALUCt1.ALUCtrlOut) {
	case 0:
		ALUResult = input1 & input2;
		break;
	case 1:
		ALUResult = input1 | input2;
		break;
	case 2:
		ALUResult = input1 + input2;
		break;
	case 3:
		ALUResult = input1 ^ input2;
		break;
	case 4:
		ALUResult = input2 << shift_amt;
		break;
	case 5:
		ALUResult = input2 >> shift_amt;

		// for shift right arithmetic
		if (InstMem.funct == 3 || InstMem.funct == 7) {
			int sign_bit = input2 >> 31;
			if (sign_bit) {
				uint32_t mask_pattern = 0xffffffff;
				mask_pattern <<= (32 - shift_amt);
				ALUResult |= mask_pattern;
			}
		}

		break;
	case 6:
		ALUResult = input1 - input2;

		// for branching
		if (!ALUResult) Zero = ~Zero;

		// for set on less than
		if (InstMem.funct == 42 || InstMem.funct == 43 || InstMem.op == 10 || InstMem.op == 11) {
			int sign_bit = ALUResult >> 31;
			if (sign_bit) ALUResult = 1;
			else ALUResult = 0;
		}

		break;
	case 7:
		if (InstMem.funct == 10 && !input2)
			ALUResult = input1;
		else if (InstMem.funct == 11 && input2)
			ALUResult = input1;
		else if (InstMem.funct == 16)
			ALUResult = RF1.hi;
		else if (InstMem.funct == 18)
			ALUResult = RF1.lo;
		else if (InstMem.funct == 17) {
			RF1.hi = input1;
			ALUResult = RF1.registers[InstMem.rd]; // rd will be written back to rd
		}
		else if (InstMem.funct == 19) {
			RF1.lo = input1;
			ALUResult = RF1.registers[InstMem.rd];
		}
		else
			ALUResult = RF1.registers[InstMem.rd];
		break;
	case 8: {
		ALUResult = RF1.registers[InstMem.rd];

		int64_t mul_input1 = input1;
		int64_t mul_input2 = input2;

		if (InstMem.funct == 24) {
			if (input1 >> 31)
				mul_input1 |= 0xffffffff00000000;
			if (input2 >> 31)
				mul_input2 |= 0xffffffff00000000;
		}

		int64_t prod = mul_input1 * mul_input2;
		RF1.lo = prod & 0x00000000ffffffff;
		RF1.hi = prod >> 32;

		break;
	}
	case 9:
		ALUResult = RF1.registers[InstMem.rd];

		if (InstMem.funct == 27) {
			RF1.lo = input1 / input2;
			RF1.hi = input1 % input2;
		}

		else if (InstMem.funct == 26) {
			RF1.lo = int32_t(input1) / int32_t(input2);
			RF1.hi = int32_t(input1) % int32_t(input2);
		}

		break;
	case 10:
		if (InstMem.funct == 9) { // if jalr (jump-and-link-register)
			// since branch prediction with a branch delay slot is 
			// not being implemented, just go to the next instuction
			if (InstMem.rd) 
				RF1.registers[InstMem.rd] = PC1.pc + 4;
			else 
				RF1.registers[31] = PC1.pc + 4;
		}

		ALUResult = RF1.registers[InstMem.rd];
		PC1.pc = input1;

		break;
	case 11: {
		ALUResult = RF1.registers[InstMem.rd];
		uint32_t curr_addr = RF1.registers[4];

		int byte_num = curr_addr % 4; // if accessing a byte or halfword

		if (RF1.registers[2] == 1) // print_int
			cout << RF1.registers[4] << endl;

		else if (RF1.registers[2] == 4) { // print_string

			map<uint32_t, uint32_t>::iterator it;
			for (it = data_segment.begin(); it != data_segment.end(); it++) {
				if (it->second == 0) break;
				if (it->first != curr_addr - byte_num) continue; // condition always false after hitting target byte
				else {
					curr_addr -= byte_num; // make sure it is word aligned to extract bits
					switch (byte_num) {
					case 0:
						cout << char((data_segment[curr_addr] & 0xff000000) >> 24);
					case 1:
						cout << char((data_segment[curr_addr] & 0x00ff0000) >> 16);
					case 2:
						cout << char((data_segment[curr_addr] & 0x0000ff00) >> 8);
					case 3:
						cout << char(data_segment[curr_addr] & 0x000000ff);
					default:
						curr_addr += 4;
						byte_num = 0;
					}

				}
			}
			cout << endl;
		}

		else if (RF1.registers[2] == 5) { // read_int
			cin >> RF1.registers[2];
		}
		else if (RF1.registers[2] == 8) { // read_string
			cin >> data_segment[RF1.registers[4]];
		}
		else if (RF1.registers[2] == 10) { // exit
			system("pause");
			exit(0);
		}

		break;

	}

	case 12:
		ALUResult = ~(input1 | input2);
		break;
	}
	return 0;
}


ALU::~ALU()
{
}
