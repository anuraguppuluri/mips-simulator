#pragma once
#include<iostream>
#include<fstream>
#include<iterator>
#include<string>
#include<map>
#include<sstream>

using namespace std;

#include "RegFile.h"
#include "ALUControl.h"
#include "ControlUnit.h"
#include "InstructionMemory.h"
#include "ProgramCounter.h"

class ALU
{
public:
	uint32_t ALUResult, Zero;
	ALU();
	int ResetALU();
	int ALUCalc(RegFile&, ALUControl& , ControlUnit&, CInstructionMemory&, ProgramCounter&, map<uint32_t, uint32_t>);
	~ALU();
};

