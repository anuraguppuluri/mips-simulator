#include "ControlUnit.h"


ControlUnit::ControlUnit()
{
	RegDst = 0; Jump = 0; MemRead = 0; MemToReg = 0; ALUOp = 0; MemWrite = 0; ALUSrc = 0; RegWrite = 0; Branch = 0; PCSrc = 0;
}

int ControlUnit::ResetCtrlSignals() {
	RegDst = 0; Jump = 0; MemRead = 0; MemToReg = 0; ALUOp = 0; MemWrite = 0; ALUSrc = 0; RegWrite = 0; Branch = 0; PCSrc = 0;
	return 0;
}

int ControlUnit::SetCtrlSignals(uint32_t opcode) {
	// reset control signal for every instruction first
	ResetCtrlSignals();

	switch (opcode) {
	case 0: // R-format instruction
		RegDst = ~RegDst; // choose rd to write back to as opposed to rt
		ALUOp = 2; // for ALUControl to choose between r-format operations 
		RegWrite = ~RegWrite;
		break;
	case 32: // load byte
	case 33: // load halfword
	case 35: // load word
	case 36: // load byte unsigned
	case 37: // load halfword unsigned
		MemRead = ~MemRead; 
		MemToReg = ~MemToReg; // choose data_out to write back as opposed to ALUResult
		ALUSrc = ~ALUSrc; // choose imm16 as input2 for ALU as opposed to rt_data
		RegWrite = ~RegWrite;
		break;
	case 40: // store byte
	case 41: // store halfword
	case 43: // store word
		MemWrite = ~MemWrite; 
		ALUSrc = ~ALUSrc;
		break;
	// branch instructions
	case 4: // beq
	case 5: // bne
	case 6: // blez
	case 7: // bgtz
		Branch = ~Branch;
		ALUOp = 1; // subtract 
		break;
	case 8: // addi
	case 9: // addiu
	case 15: // lui
		RegWrite = ~RegWrite;
		ALUSrc = ~ALUSrc;
		break;
	case 10: // slti
	case 11: // sltiu
		ALUOp = 1; // subtract
		ALUSrc = ~ALUSrc;
		RegWrite = ~RegWrite;
		break;
	case 12: // andi
	case 13: // ori
	case 14: // xori
		ALUOp = 3; // neither r-format, nor an add or subtract
		ALUSrc = ~ALUSrc;
		RegWrite = ~RegWrite;
		break;
	case 2: // JUMP instruction
	case 3: // JUMP AND LINK instruction
		Jump = ~Jump; 
		break;
	}

	return 0;
}

int ControlUnit::SetPCSrc(uint32_t Zero, CInstructionMemory& InstMem, uint32_t ALUResult) {
	int sign_bit = ALUResult >> 31;
	uint32_t isNegative = 0; // this flag is set when ALUResult is negative
	if (sign_bit) isNegative = ~isNegative;

	if (InstMem.op == 4) // beq; sets PCSrc when ALUResult is zero
		PCSrc = Branch & Zero;

	else if (InstMem.op == 5) // bne; sets PCSrc when ALUResult is non-zero
		PCSrc = Branch & ~Zero;

	else if (InstMem.op == 6) // blez; sets PCSrc when either ALUResult is 0 or negative
		PCSrc = Branch & Zero | isNegative;

	else if (InstMem.op == 7) // bgtz; sets PCSrc when ALUResult is positive
		PCSrc = Branch & ~Zero & ~isNegative;

	return 0;
}

ControlUnit::~ControlUnit()
{
}
