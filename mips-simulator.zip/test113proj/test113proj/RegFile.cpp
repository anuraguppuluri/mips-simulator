#include "RegFile.h"



RegFile::RegFile()
{
	for (uint32_t i = 0; i < 32; i++)
		registers.insert(make_pair(i, 0));
}

int RegFile::PrintRegFile()
{
	// test reg file
	int i = 0;
	map<uint32_t, uint32_t>::iterator it;

	cout << "*********************REGISTER*FILE**************************" << endl;
	for (it = registers.begin(); it != registers.end(); it++) {
		cout << dec << i++ << " ";
		cout << hex << it->first << " -> " << it->second << endl;
	}
	cout << "HI -> " << hi << endl;
	cout << "LO -> " << lo << endl;
	cout << dec << "Size: " << registers.size() << endl;
	return 0;
}

int RegFile::ReadRS(CInstructionMemory& InstMem) {
	rs_data = registers[InstMem.rs];
	return 0;
}

int RegFile::ReadRT(CInstructionMemory& InstMem) {
	// create appropriate partial mask pattern for sb and sh
	if (InstMem.op == 40)
		rt_data = registers[InstMem.rt] & 0x000000ff;
	else if (InstMem.op == 41)
		rt_data = registers[InstMem.rt] & 0x0000ffff;
	else
		rt_data = registers[InstMem.rt];
	return 0;
}

uint32_t RegFile::ALUInput2(CInstructionMemory& InstMem, ControlUnit& CU1) {
	ReadRT(InstMem);
	Multiplexor ALUInput2Mux = Multiplexor(rt_data, InstMem.imm16, CU1.ALUSrc);
	return ALUInput2Mux.mux_out;
}

int RegFile::WriteReg(CInstructionMemory& InstMem, ControlUnit& CU1, uint32_t write_data) {
	if (CU1.RegWrite) {
		Multiplexor rtRdMux = Multiplexor(InstMem.rt, InstMem.rd, CU1.RegDst);
		write_reg = rtRdMux.mux_out;
		registers[write_reg] = write_data;
	}
	return 0;
}

RegFile::~RegFile()
{
}
