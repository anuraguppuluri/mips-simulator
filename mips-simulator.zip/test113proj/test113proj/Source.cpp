#include<iostream>
#include<fstream>
#include<iterator>
#include<string>
#include<map>
#include<sstream>

#include "InputManager.h"
#include "InstructionMemory.h"
#include "DataMemory.h"
#include "RegFile.h"
#include "ProgramCounter.h"
#include "ControlUnit.h"
#include "ALU.h"
#include "Stack.h"

using namespace std;

int main(int argc, char* argv[]) {

	    //string fileName = argv[1];
		//string fileName = "C:\\Users\\anura\\OneDrive\\csufr\\myfresnostate\\intro comp org\\lab\\113proj\\test113proj\\Debug\\corrected_hex_from_pdf_workable.txt";
		string fileName = "C:\\Users\\anura\\OneDrive\\csufr\\myfresnostate\\intro comp org\\lab\\113proj\\test113proj\\Debug\\final_demo_hex_c.txt";

		CInstructionMemory InstMem; 
		CDataMemory DataMem;
		CInputManager InpManage = CInputManager(fileName, InstMem, DataMem);

		InstMem.PrintInstrMem();
		DataMem.PrintDataMem();

		RegFile RF1;

		CStack St;

		RF1.registers[28] = 0x10008000;
		RF1.registers[29] = 0x7ffff000;
		// since first valid aligned stack addr should be 0x7fffeffc

		/*
		RF1.registers[8] = 0x4004;
		RF1.registers[9] = 0xeffa;
		RF1.registers[10] = 0xb801;
		RF1.registers[11] = 0xffffeff7;
		RF1.registers[12] = 1;
		RF1.registers[13] = 0x53fc;
		RF1.registers[14] = 0x6405;
		RF1.registers[15] = 0;
		RF1.registers[16] = 0x10010000;
		RF1.registers[17] = 0x23;
		RF1.registers[18] = 0x10;
		RF1.registers[19] = 0x2a;
		RF1.registers[20] = 0x13;

		RF1.registers[1] = 0x0040003c;
		RF1.PrintRegFile();

		RF1.registers[13] = 0x53fc;
		RF1.registers[14] = 0x6405;

		RF1.registers[16] = 0x10010000;
		RF1.registers[24] = 0x0;

		RF1.registers[25] = 0x0;

		RF1.registers[8] = 0x10010014;
		RF1.registers[9] = 9;
		RF1.registers[10] = 9;
		RF1.registers[11] = 9;
		RF1.registers[12] = 9;
		RF1.registers[13] = 9;
		RF1.registers[14] = 9;
		RF1.registers[15] = 9;
		RF1.registers[16] = 9;
		RF1.registers[17] = 9;
		RF1.registers[18] = 9;
		RF1.registers[19] = 9;
		RF1.registers[20] = 9;
		RF1.registers[7] = 9;
		RF1.registers[6] = 9;
		RF1.registers[5] = 9;
		RF1.registers[4] = 9;
		RF1.registers[3] = 9;
		RF1.registers[2] = 9;
		RF1.registers[1] = 9;
		RF1.registers[21] = 9;
		RF1.registers[22] = 9;
		RF1.registers[23] = 9;
		RF1.registers[24] = 9;
		RF1.registers[25] = 9;
		RF1.registers[26] = 9;
		RF1.registers[27] = 9;
		*/

		// Instantiate program counter to beginning of program 
		ProgramCounter PC1; 
		ControlUnit CU1;
		ALU ALU1;
		ALUControl ALUCt;
		uint32_t curr_inst = InstMem.GetTextAtAddress(PC1.pc); // This is the current instruction 

		while (curr_inst != 0) {
			// Decode the instruction 
			InstMem.GetInstrFields(curr_inst); 

			// Read rs
			RF1.ReadRS(InstMem);

			// Read rt
			RF1.ReadRT(InstMem);

			// Set Control Lines
			CU1.SetCtrlSignals(InstMem.op);

			// generate ALU function
			ALUCt.SetALUCtrl(CU1.ALUOp, InstMem.funct, InstMem.op);

			// Execute the instruction 
			ALU1.ALUCalc(RF1, ALUCt, CU1, InstMem, PC1, DataMem.data_segment);

			// is this a branch?
			CU1.SetPCSrc(ALU1.Zero, InstMem, ALU1.ALUResult);

			// Update PC to next instruction
			PC1.UpdatePC(InstMem, CU1, RF1);

			// write from rt to address computed by ALU (for a store)
			DataMem.WriteDataToMem(RF1, CU1, ALU1, InstMem, St);

			// get data at address computed by ALU
			DataMem.GetDataAtAddress(ALU1, InstMem, St);

			// Write to rd (for an r-type) or rt (for a load)
			DataMem.WriteRegData(ALU1, CU1);
			RF1.WriteReg(InstMem, CU1, DataMem.write_data);

			// print reg file
			//RF1.PrintRegFile();

			// print data memory (for a store)
			//DataMem.PrintDataMem();

			// print stack
			//St.PrintStack();

			// focus on the new instruction
			curr_inst = InstMem.GetTextAtAddress(PC1.pc);
		}

		InstMem.PrintInstrMem();

	system("pause");
	return 0;
}
