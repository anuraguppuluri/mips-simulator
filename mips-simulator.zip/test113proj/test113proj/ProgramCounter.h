#pragma once
#include<iostream>
#include<fstream>
#include<iterator>
#include<string>
#include<map>
#include<sstream>

#include "Multiplexor.h"
#include "InstructionMemory.h"
#include "ControlUnit.h"
#include "RegFile.h"

using namespace std;

class ProgramCounter
{
public:
	uint32_t pc, incPC, branchPC, jumpPC;

	ProgramCounter();
	int UpdatePC(CInstructionMemory&, ControlUnit&, RegFile&);
	~ProgramCounter();
};

