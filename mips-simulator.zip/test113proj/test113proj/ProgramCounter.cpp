#include "ProgramCounter.h"



ProgramCounter::ProgramCounter()
{
	pc = 0x00400000;
}

int ProgramCounter::UpdatePC(CInstructionMemory& InstMem, ControlUnit& CU1, RegFile& RF1) {
	// if not an r-format jump instruction
	if (!(InstMem.funct == 8 && InstMem.op == 0) && !(InstMem.funct == 9 && InstMem.op == 0)) {

		incPC = pc + 4; // generic case

		// for a jal
		if (InstMem.op == 3)
			RF1.registers[31] = incPC;

		//branchPC = incPC + InstMem.branchImm16; // for a branch
		branchPC = pc + InstMem.branchImm16; // for a branch

												// extract first four bits of PC for concatenation for a jump
		jumpPC = incPC & 0xf0000000;
		jumpPC |= InstMem.imm26;

		Multiplexor incBranchMux = Multiplexor(incPC, branchPC, CU1.PCSrc);
		pc = incBranchMux.mux_out;

		Multiplexor incBranchJumpMux = Multiplexor(pc, jumpPC, CU1.Jump);
		pc = incBranchJumpMux.mux_out;
	}
	return 0;
}
ProgramCounter::~ProgramCounter()
{
}
