#pragma once
#include<iostream>
#include<fstream>
#include<iterator>
#include<string>
#include<map>
#include<sstream>
using namespace std;

#include "InstructionMemory.h"
#include "Multiplexor.h"
#include "ControlUnit.h"

class RegFile
{
public:
	// register map
	map<uint32_t, uint32_t> registers;

	uint32_t rs_data, rt_data, write_reg;
	
	int32_t hi, lo;

	RegFile();
	int PrintRegFile();
	int ReadRS(CInstructionMemory&);
	int ReadRT(CInstructionMemory&);
	uint32_t ALUInput2(CInstructionMemory&, ControlUnit&);
	int WriteReg(CInstructionMemory&, ControlUnit&, uint32_t);
	~RegFile();
};

