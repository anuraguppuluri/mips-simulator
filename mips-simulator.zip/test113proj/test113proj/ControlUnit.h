#pragma once
#include<iostream>
#include<fstream>
#include<iterator>
#include<string>
#include<map>
#include<sstream>
using namespace std;

#include "InstructionMemory.h"

class ControlUnit
{
public:
	uint32_t RegDst, Jump, MemRead, MemToReg, ALUOp, MemWrite, ALUSrc, RegWrite, Branch, PCSrc;
	ControlUnit();
	int ResetCtrlSignals();
	int SetCtrlSignals(uint32_t);
	int SetPCSrc(uint32_t, CInstructionMemory&, uint32_t);
	~ControlUnit();
};

