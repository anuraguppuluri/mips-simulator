#pragma once
#include<iostream>
#include<fstream>
#include<iterator>
#include<string>
#include<map>
#include<sstream>

using namespace std;

class CStack
{
public:

	// for storing stack addresses in decreasing order  
	struct classcomp {
		bool operator() (const uint32_t& lhs, const uint32_t& rhs) const
		{
			return lhs>rhs;
		}
	};
	// Instruction memory map
	// define map for instruction space
	map<uint32_t, uint32_t, classcomp> stack_segment;
	uint32_t stack_addr = 0x7fffeffc;

	CStack();
	int PrintStack();
	uint32_t GetStackValue(uint32_t);
	~CStack();
};

