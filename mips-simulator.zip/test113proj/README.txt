solution can be opened in visual studio 2015 community

2 kB text segment = 2048/4 = 512 words

Notes:-
In this project, main() takes the name of the hex file as an argument. So please copy the hex file into the debug folder of the root project directory and also copy the file path to the "Command Arguments" column in 
Debug/Project Menu -> Project Properties -> Debugging (left panel)
in Visual Studio.
Also, please use escape sequences for the backslashs in the file path i.e., "C:\\intro comp org\\lab\\113proj\\test113proj\\Debug\\demo_hex.txt" instead of "C:\intro comp org\lab\113proj\test113proj\Debug\demo_hex.txt".
Or, better yet, just copy the file path to the "fileName" argument to the InputManager class in source.cpp.    

1. Input instructions in InstMem class 
2. source control first commit 
3. Input data in DataMem class 
4. Maintain PC in InstMem class 
5. Add functions to your InstMem class to split an instruction into bit groups
6. Start workign on control class 